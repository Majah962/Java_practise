package hr.java.oop.entiteti;

public enum NumberDoor {

	THREE,
	FIVE,
	SEVEN
}
