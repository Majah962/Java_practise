package hr.java.oop.entiteti;

public enum Color {

	RED,
	BLUE,
	WHITE
}
