package hr.java.oop.entiteti;

public interface Vozila {
	
	void startT (Driver xDriver);
	void stopT (Driver xDriver);
	void serviceT (Repairman xRepairman);

}
